from pathlib import Path
import sys
import joblib
import numpy as np
import pandas as pd
from catboost import CatBoostRegressor

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'Analysis'))
import analyse

source = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / 'Results/Eligible Hourly Samples.csv'
data = pd.read_csv(source, parse_dates=['time'])
data.columns = [x.replace(' ', '_') for x in data.columns]
folder = root / 'Results/Models'
configuration = joblib.load(folder / 'Mappings and Feature Lists.joblib')
forecast = np.zeros(len(data))
for state, label, features in [(0, 'Full', configuration['onsetFeatures']), (1, 'Reduced', configuration['persistenceFeatures'])]:
    mask = data.current_severe.to_numpy() == state
    if not mask.any():
        continue
    values = []
    for path in ['Residual', 'Direct']:
        for seed in [17, 42, 91]:
            model = CatBoostRegressor()
            model.load_model(str(folder / (label + ' ' + path + ' Seed ' + str(seed) + '.cbm')))
            prediction = model.predict(data.loc[mask, features])
            values.append(prediction + data.loc[mask, 'expected_mass'].to_numpy() if path == 'Residual' else prediction)
    forecast[mask] = np.mean(values, axis=0)
raw = -forecast / data.next_baseline.to_numpy()
probability = configuration['probabilityModel'].predict_proba(configuration['probabilityScaler'].transform(pd.DataFrame({'raw': raw})))[:, 1]
_, decision = configuration['decision'].predict(data, raw)
warning = [int(score >= configuration['thresholds'][int(state)]) for score, state in zip(decision, data.current_severe)]
result = pd.DataFrame({'Time': data.time, 'Predicted next hour tonnage': forecast, 'Normalised risk': raw, 'Severe probability': probability, 'Decision score': decision, 'Warning': warning})
result.to_csv(root / 'Results/Saved Model Predictions.csv', index=False)
print(result.to_string(index=False))
