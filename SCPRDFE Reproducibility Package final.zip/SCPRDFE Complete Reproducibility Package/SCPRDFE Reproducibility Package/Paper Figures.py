from pathlib import Path
import zipfile
import io
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, precision_recall_curve, roc_auc_score, average_precision_score, confusion_matrix

root = Path(__file__).resolve().parent
results = root / 'Results'
out = results / 'Figures'
out.mkdir(exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11, 'svg.fonttype': 'none', 'axes.spines.top': False, 'axes.spines.right': False})
p = pd.read_csv(results / 'Final Predictions.csv', parse_dates=['time'])
colours = ['#0072b2', '#d55e00', '#009e73']
groups = [('Overall', p), ('Onset', p[p['current severe'] == 0]), ('Persistence', p[p['current severe'] == 1])]
def finish(fig, name, title, handles=None, labels=None):
    fig.suptitle(title, y=.985, fontsize=16, fontweight='bold')
    if handles:
        fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(.5, .945), ncol=len(handles), frameon=False)
    fig.tight_layout(rect=[0, .02, 1, .86])
    for suffix in ['png', 'svg']:
        buffer = io.BytesIO()
        fig.savefig(buffer, format=suffix, dpi=600, facecolor='white')
        payload = buffer.getvalue()
        if suffix == 'svg':
            payload = payload.replace(b"font-family: 'DejaVu Sans'", b'font-family: Arial, Helvetica, sans-serif')
        if suffix == 'png' and not payload.endswith(b'IEND\xaeB`\x82'):
            raise RuntimeError('Incomplete PNG encoding')
        temporary = out / (name + '.temporary')
        with temporary.open('wb') as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(out / (name + '.' + suffix))
    plt.close(fig)
fig, axes = plt.subplots(1, 2, figsize=(12, 5.7))
handles = []
labels = []
for (label, q), colour in zip(groups, colours):
    fpr, tpr, _ = roc_curve(q.y, q.raw)
    precision, recall, _ = precision_recall_curve(q.y, q.raw)
    handle, = axes[0].plot(fpr, tpr, color=colour, lw=2)
    axes[1].plot(recall, precision, color=colour, lw=2)
    handles.append(handle)
    labels.append(label + '\nAUROC ' + f'{roc_auc_score(q.y, q.raw):.3f}' + '   AP ' + f'{average_precision_score(q.y, q.raw):.3f}')
axes[0].plot([0, 1], [0, 1], color='#777777', linestyle=':')
for ax, title, xlabel, ylabel in [(axes[0], 'a. Receiver operating characteristic', 'False positive rate', 'True positive rate'), (axes[1], 'b. Precision and recall', 'Recall', 'Precision')]:
    ax.set(title=title, xlabel=xlabel, ylabel=ylabel, xlim=(0, 1), ylim=(0, 1.02))
finish(fig, 'Ranking Performance', 'Ranking of severe next hour flow', handles, labels)
fig, axes = plt.subplots(4, 1, figsize=(12, 10), sharex=True)
x = np.arange(len(p))
h1, = axes[0].plot(x, p['next dest ton'], color='#0072b2', label='Observed tonnage')
h2, = axes[0].plot(x, p.forecast, color='#d55e00', label='Forecast tonnage')
h3, = axes[0].plot(x, .5 * p['next baseline'], color='#777777', linestyle=':', label='Severe flow boundary')
axes[1].plot(x, p.raw, color='#009e73')
axes[2].plot(x, p.probability, color='#0072b2')
axes[2].scatter(x[p.y == 1], p.probability[p.y == 1], s=13, color='#d55e00')
axes[3].plot(x, p['decision score'], color='#0072b2')
axes[3].plot(x, np.where(p['current severe'] == 0, .67, .81), color='#777777', linestyle=':')
axes[3].scatter(x[p.prediction == 1], p['decision score'][p.prediction == 1], s=13, color='#d55e00')
for ax, title, ylabel in zip(axes, ['a. Material received in the following hour', 'b. Normalised risk', 'c. Calibrated probability with severe outcome markers', 'd. Decision score and threshold with warning markers'], ['Tonnes', 'Risk', 'Probability', 'Decision score']):
    ax.set(title=title, ylabel=ylabel)
axes[3].set_xlabel('Chronological monitored observation index')
finish(fig, 'Chronological Forecasts', 'Chronological forecasts and warnings', [h1, h2, h3], ['Observed tonnage', 'Forecast tonnage', 'Severe flow boundary'])
fig, axes = plt.subplots(1, 2, figsize=(12, 5.7))
matrix = confusion_matrix(p.y, p.prediction, labels=[0, 1])
axes[0].imshow(matrix, cmap='Blues')
for i in range(2):
    for j in range(2):
        axes[0].text(j, i, str(matrix[i, j]), ha='center', va='center', fontsize=20, fontweight='bold', color='white' if matrix[i, j] > matrix.max() / 2 else '#18283a')
axes[0].set(xticks=[0, 1], xticklabels=['Predicted adequate', 'Predicted severe'], yticks=[0, 1], yticklabels=['Actual adequate', 'Actual severe'], title='a. Confusion matrix')
branch = groups[1:]
x = np.arange(2)
b1 = axes[1].bar(x - .18, [roc_auc_score(q.y, q.raw) for _, q in branch], .36, color='#0072b2')
b2 = axes[1].bar(x + .18, [average_precision_score(q.y, q.raw) for _, q in branch], .36, color='#d55e00')
for bars in [b1, b2]:
    axes[1].bar_label(bars, fmt='%.3f', padding=3)
axes[1].set(xticks=x, xticklabels=['Onset', 'Persistence'], ylim=(0, 1.1), ylabel='Score', title='b. Onset and persistence discrimination')
finish(fig, 'Classification and Branch Performance', 'Classification and state conditional performance', [b1, b2], ['AUROC', 'Average precision'])
fig, axes = plt.subplots(1, 3, figsize=(15, 5.8))
m = pd.read_csv(results / 'Component and Rule Metrics.csv')
m = m[(m.group == 'Overall') & m.model.isin(['SCPRDFE', 'Residual path', 'Direct path', 'Full pipeline', 'No pipeline'])].copy()
y = np.arange(len(m))
b1 = axes[0].barh(y - .17, m.auc, .34, color='#0072b2')
b2 = axes[0].barh(y + .17, m.ap, .34, color='#d55e00')
axes[0].set(yticks=y, yticklabels=m.model, xlim=(0, 1), xlabel='Score', title='a. Matched components')
bins = pd.read_csv(results / 'Probability Bins.csv')
axes[1].plot([0, 1], [0, 1], color='#777777', linestyle=':')
axes[1].plot(bins.meanProbability, bins.observedFrequency, marker='o', color='#009e73')
axes[1].set(xlim=(0, 1), ylim=(0, 1), xlabel='Mean predicted probability', ylabel='Observed severe frequency', title='b. Probability calibration')
delay = pd.read_csv(results / 'Reporting Delay Metrics.csv')
delay = delay[delay.group == 'Overall']
minutes = delay.model.str.replace('Delay ', '', regex=False).astype(int)
axes[2].plot(minutes, delay.auc, marker='o', color='#0072b2')
axes[2].plot(minutes, delay.f1, marker='s', color='#009e73')
axes[2].set(xticks=[0, 15, 30, 60], ylim=(0, 1), xlabel='Reporting delay in minutes', ylabel='Score', title='c. Reporting delay sensitivity')
from matplotlib.lines import Line2D
finish(fig, 'Components Calibration and Delay', 'Component comparisons, probability calibration and reporting delay', [Line2D([0], [0], color='#0072b2', lw=3), Line2D([0], [0], color='#d55e00', lw=3), Line2D([0], [0], color='#009e73', lw=3)], ['AUROC', 'Average precision', 'F1 in panel c'])
with zipfile.ZipFile(results / 'HD Figures.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(out.glob('*')):
        archive.write(file, 'Figures/' + file.name)
print('Generated four manuscript figures as 600 dpi PNG and editable SVG files')
