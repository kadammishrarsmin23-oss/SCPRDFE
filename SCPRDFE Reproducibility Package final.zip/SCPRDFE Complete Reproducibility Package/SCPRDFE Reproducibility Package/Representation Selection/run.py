from pathlib import Path
import sys, json
import numpy as np, pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'Analysis'))
import analyse as a
a.OUT = ROOT / 'Representation Selection'
d = pd.read_csv(ROOT / 'Analysis/Cutoff Samples.csv', parse_dates=['time'])
pipeline = set(a.base.featureFamilies['in_transit_pipeline'])
keep = {'open_count', 'open_mass', 'open_age_med', 'open_age_p90', 'pipeline_to_baseline'}
candidates = [('Reduced pipeline', [c for c in a.FEATURES if c not in pipeline or c in keep], 'mixed'), ('No pipeline no month', [c for c in a.FEATURES if c not in pipeline and c not in ['month', 'month_sin', 'month_cos']], 'mixed'), ('Symmetric branch loss', a.FEATURES, 'mean')]
for name, cols, loss in candidates:
    z = d.copy()
    if name == 'No pipeline no month':
        z.expected_mass = 0
        z.residual_target = z.next_dest_ton
    a.run_model(name, z, features=cols, loss=loss, dataset='refinement')
paths = {}
for name in ['SCPRDFE', 'Residual only', 'Direct only', 'Without recency', 'Without month']:
    paths[name] = (ROOT / 'Analysis' / ('primary ' + name + ' Development.csv'), ROOT / 'Analysis' / ('primary ' + name + ' Predictions.csv'))
paths['Without pipeline'] = (ROOT / 'Analysis/no pipeline Without pipeline Development.csv', ROOT / 'Analysis/no pipeline Without pipeline Predictions.csv')
for name, _, _ in candidates:
    paths[name] = (a.OUT / ('refinement ' + name + ' Development.csv'), a.OUT / ('refinement ' + name + ' Predictions.csv'))
devs = {n: pd.read_csv(p[0], parse_dates=['time']).sort_values('time').reset_index(drop=True) for n, p in paths.items()}
anchor = devs['SCPRDFE']
assert all((v.time.equals(anchor.time) and v.y.equals(anchor.y) for v in devs.values()))

def fast_threshold(y, score):
    grid = np.round(np.arange(0.01, 1, 0.01), 2)
    yp = np.asarray(y, int)
    pred = np.asarray(score)[:, None] >= grid[None, :]
    tp = (pred & (yp[:, None] == 1)).sum(axis=0)
    fp = (pred & (yp[:, None] == 0)).sum(axis=0)
    fn = yp.sum() - tp
    tn = len(yp) - yp.sum() - fp
    rec = tp / max(1, yp.sum())
    spe = tn / max(1, len(yp) - yp.sum())
    ba = (rec + spe) / 2
    f1 = 2 * tp / np.maximum(1, 2 * tp + fp + fn)
    prec = tp / np.maximum(1, tp + fp)
    h = 2 * ba * f1 / np.maximum(1e-12, ba + f1)
    best = max(range(len(grid)), key=lambda i: (h[i], rec[i], prec[i], -abs(grid[i] - 0.5), grid[i]))
    return float(grid[best])
v = anchor[anchor.time >= '2025-05-01']
assert fast_threshold(v.y, np.linspace(0, 1, len(v))) == a.base.chooseThreshold(v.y.to_numpy(), np.linspace(0, 1, len(v)))
rows = []
configs = {}
for onset in devs:
    for persistence in devs:
        z = anchor.copy()
        mask = z.current_severe == 0
        z['forecast'] = np.where(mask, devs[onset].forecast, devs[persistence].forecast)
        z['raw'] = -z.forecast / z.next_baseline
        cal = z[z.time < '2025-05-01']
        valid = z[z.time >= '2025-05-01']
        mapping = a.Mapping(cal)
        prob, dec = mapping.predict(valid, valid.raw)
        pred = np.zeros(len(valid), int)
        ths = {}
        branch = []
        for st in [0, 1]:
            m = valid.current_severe.to_numpy() == st
            ths[st] = fast_threshold(valid.loc[m, 'y'].to_numpy(), dec[m])
            pred[m] = dec[m] >= ths[st]
            mt = a.metric(valid.loc[m, 'y'], pred[m], prob[m], prob[m])
            branch.append(2 * mt['balanced_accuracy'] * mt['f1'] / max(1e-12, mt['balanced_accuracy'] + mt['f1']))
        mt = a.metric(valid.y, pred, prob, prob)
        score = float(np.mean(branch))
        key = onset + ' | ' + persistence
        rows.append(dict(candidate=key, onset=onset, persistence=persistence, selection_score=score, mae=mean_absolute_error(valid.next_dest_ton, valid.forecast), **mt))
        configs[key] = (mapping, ths)
ranking = pd.DataFrame(rows).sort_values(['selection_score', 'auc'], ascending=False)
ranking.to_csv(a.OUT / 'Development Selection.csv', index=False)
baseline = ranking[ranking.candidate == 'SCPRDFE | SCPRDFE'].iloc[0]
ranking['eligible'] = (ranking.recall >= baseline.recall - 1e-12) & (ranking.brier <= baseline.brier + 1e-12) & (ranking.mae <= baseline.mae + 1e-12)
ranking.to_csv(a.OUT / 'Development Selection.csv', index=False)
best = ranking[ranking.eligible].iloc[0]
mapping, ths = configs[best.candidate]
p0 = pd.read_csv(paths[best.onset][1], parse_dates=['time']).sort_values('time').reset_index(drop=True)
p1 = pd.read_csv(paths[best.persistence][1], parse_dates=['time']).sort_values('time').reset_index(drop=True)
orig = pd.read_csv(paths['SCPRDFE'][1], parse_dates=['time']).sort_values('time').reset_index(drop=True)
assert p0.time.equals(p1.time) and p0.time.equals(orig.time) and p0.y.equals(orig.y)
z = p0.copy()
z['forecast'] = np.where(z.current_severe == 0, p0.forecast, p1.forecast)
z['raw'] = -z.forecast / z.next_baseline
z['probability'], z['decision_score'] = mapping.predict(z, z.raw)
z['prediction'] = [int(s >= ths[int(st)]) for s, st in zip(z.decision_score, z.current_severe)]
z.to_csv(a.OUT / 'Selected Predictions.csv', index=False)
metrics = []
for name, v in [('SCPRDFE reference', orig), ('SCPRDFE', z)]:
    for st, label in [(None, 'Overall'), (0, 'Onset'), (1, 'Persistence')]:
        q = v if st is None else v[v.current_severe == st]
        metrics.append(dict(model=name, group=label, **a.metric(q.y, q.prediction, q.raw, q.probability), mae=mean_absolute_error(q.next_dest_ton, q.forecast), rmse=mean_squared_error(q.next_dest_ton, q.forecast) ** 0.5))
pd.DataFrame(metrics).to_csv(a.OUT / 'Comparison Metrics.csv', index=False)
summary = dict(selected_onset=best.onset, selected_persistence=best.persistence, thresholds=ths, candidate_count=len(ranking), development_score=float(best.selection_score), original_development_score=float(ranking.loc[ranking.candidate == 'SCPRDFE | SCPRDFE', 'selection_score'].iloc[0]), later_evaluation_not_untouched=True)
(a.OUT / 'Selection.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2), flush=True)
print(pd.DataFrame(metrics).to_string(index=False), flush=True)
rng = np.random.default_rng(20261009)
dates = z.time.dt.normalize()
unique = dates.drop_duplicates().to_numpy()
groups = [np.where(dates.to_numpy() == dt)[0] for dt in unique]
bs = []
for i in range(2000):
    ix = []
    while len(ix) < len(groups):
        start = rng.integers(len(groups))
        ix.extend([(start + j) % len(groups) for j in range(3)])
    inds = np.concatenate([groups[j] for j in ix[:len(groups)]])
    u = z.iloc[inds]
    v = orig.iloc[inds]
    if u.y.nunique() < 2:
        continue
    um = a.metric(u.y, u.prediction, u.raw)
    vm = a.metric(v.y, v.prediction, v.raw)
    bs.append(dict(auc=um['auc'] - vm['auc'], f1=um['f1'] - vm['f1'], mae=mean_absolute_error(u.next_dest_ton, u.forecast) - mean_absolute_error(v.next_dest_ton, v.forecast)))
b = pd.DataFrame(bs)
intervals = {c: [float(b[c].quantile(0.025)), float(b[c].quantile(0.975))] for c in b}
(a.OUT / 'Paired Intervals.json').write_text(json.dumps(intervals, indent=2))
print(intervals, flush=True)
