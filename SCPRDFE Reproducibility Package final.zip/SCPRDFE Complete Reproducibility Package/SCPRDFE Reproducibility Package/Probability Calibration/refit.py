from pathlib import Path
import sys, json
import pandas as pd, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'Analysis'))
import analyse as a
O = ROOT / 'Probability Calibration'
x = pd.read_csv(ROOT / 'Analysis/primary SCPRDFE Development.csv', parse_dates=['time']).sort_values('time').reset_index(drop=True)
v = pd.read_csv(ROOT / 'Representation Selection/refinement Reduced pipeline Development.csv', parse_dates=['time']).sort_values('time').reset_index(drop=True)
x['forecast'] = np.where(x.current_severe == 0, x.forecast, v.forecast)
x['raw'] = -x.forecast / x.next_baseline
cal = x[x.time < '2025-05-01']
valid = x[x.time >= '2025-05-01']
rows = []

def fit(z, weighted):
    scaler = StandardScaler().fit(z[['raw']])
    model = LogisticRegression(C=1, max_iter=5000, solver='lbfgs', random_state=0)
    model.fit(scaler.transform(z[['raw']]), z.y, sample_weight=a.base.recencyWeights(z.time) if weighted else None)
    return (scaler, model)
for weighted in [False, True]:
    scaler, model = fit(cal, weighted)
    prob = model.predict_proba(scaler.transform(valid[['raw']]))[:, 1]
    rows.append(dict(weighted=weighted, brier=float(np.mean((valid.y - prob) ** 2))))
rank = pd.DataFrame(rows).sort_values('brier')
rank.to_csv(O / 'Refit Development Selection.csv', index=False)
weighted = bool(rank.iloc[0].weighted)
assert x.time.max() + pd.Timedelta(hours=2) < pd.Timestamp('2025-07-01')
scaler, model = fit(x, weighted)
p = pd.read_csv(ROOT / 'Representation Selection/Selected Predictions.csv', parse_dates=['time'])
old = p.copy()
p['probability'] = model.predict_proba(scaler.transform(p[['raw']]))[:, 1]
p.to_csv(O / 'Refitted Predictions.csv', index=False)
metrics = []
for label, z in [('Initial probability mapping', old), ('Refitted probability calibration', p)]:
    for st, group in [(None, 'Overall'), (0, 'Onset'), (1, 'Persistence')]:
        q = z if st is None else z[z.current_severe == st]
        metrics.append(dict(model=label, group=group, **a.metric(q.y, q.prediction, q.raw, q.probability), mean_probability=float(q.probability.mean()), prevalence=float(q.y.mean())))
pd.DataFrame(metrics).to_csv(O / 'Refit Comparison Metrics.csv', index=False)
params = dict(weighted=weighted, n=len(x), events=int(x.y.sum()), mean=float(scaler.mean_[0]), scale=float(scaler.scale_[0]), intercept=float(model.intercept_[0]), slope=float(model.coef_[0, 0]), decision_mapping_unchanged=True, independent_test=False)
(O / 'Refit Parameters.json').write_text(json.dumps(params, indent=2))
print(rank.to_string(index=False), flush=True)
print(pd.DataFrame(metrics).to_string(index=False), flush=True)
rng = np.random.default_rng(20261012)
dates = p.time.dt.normalize()
unique = dates.drop_duplicates().to_numpy()
groups = [np.where(dates.to_numpy() == dt)[0] for dt in unique]
delta = []
for i in range(2000):
    ix = []
    while len(ix) < len(groups):
        start = rng.integers(len(groups))
        ix.extend([(start + j) % len(groups) for j in range(3)])
    inds = np.concatenate([groups[j] for j in ix[:len(groups)]])
    u = p.iloc[inds]
    v = old.iloc[inds]
    delta.append(float(np.mean((u.probability - u.y) ** 2) - np.mean((v.probability - v.y) ** 2)))
(O / 'Refit Paired Brier Interval.json').write_text(json.dumps(dict(difference=float(np.mean((p.probability - p.y) ** 2) - np.mean((old.probability - old.y) ** 2)), lower=float(np.quantile(delta, 0.025)), upper=float(np.quantile(delta, 0.975)), replicates=2000, block_dates=3), indent=2))
