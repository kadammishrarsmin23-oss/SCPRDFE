from pathlib import Path
import sys
import json
import hashlib
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error
from tqdm import tqdm

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'Analysis'))
import analyse as a

out = root / 'Results'
models = out / 'Models'
models.mkdir(exist_ok=True)
def save(frame, name):
    frame = frame.copy()
    frame.columns = [str(x).replace('_', ' ') for x in frame.columns]
    frame.to_csv(out / (name + '.csv'), index=False)
def probabilityFit(frame, weighted=True):
    scaler = StandardScaler().fit(frame[['raw']])
    model = LogisticRegression(C=1, max_iter=5000, solver='lbfgs', random_state=0)
    model.fit(scaler.transform(frame[['raw']]), frame.y, sample_weight=a.base.recencyWeights(frame.time) if weighted else None)
    return scaler, model
def calibrated(development, later):
    cal = development[development.time < '2025-05-01']
    valid = development[development.time >= '2025-05-01']
    mapping = a.Mapping(cal)
    _, decision = mapping.predict(valid, valid.raw)
    thresholds = {st: a.base.chooseThreshold(valid.loc[valid.current_severe == st, 'y'], decision[valid.current_severe.to_numpy() == st]) for st in [0, 1]}
    scaler, logistic = probabilityFit(development)
    later = later.copy()
    later['probability'] = logistic.predict_proba(scaler.transform(later[['raw']]))[:, 1]
    _, later['decision_score'] = mapping.predict(later, later.raw)
    later['prediction'] = [int(score >= thresholds[int(state)]) for score, state in zip(later.decision_score, later.current_severe)]
    return later, mapping, thresholds, scaler, logistic
def rows(name, frame):
    result = []
    for state, label in [(None, 'Overall'), (0, 'Onset'), (1, 'Persistence')]:
        q = frame if state is None else frame[frame.current_severe == state]
        values = a.metric(q.y, q.prediction, q.raw, q.probability)
        if 'forecast' in q:
            values.update(mae=mean_absolute_error(q.next_dest_ton, q.forecast), rmse=mean_squared_error(q.next_dest_ton, q.forecast) ** .5, bias=float((q.forecast - q.next_dest_ton).mean()))
        result.append(dict(model=name, group=label, **values))
    return result
data = pd.read_csv(root / 'Analysis/Cutoff Samples.csv', parse_dates=['time'])
full = pd.read_csv(root / 'Analysis/primary SCPRDFE Development.csv', parse_dates=['time']).sort_values('time').reset_index(drop=True)
reduced = pd.read_csv(root / 'Representation Selection/refinement Reduced pipeline Development.csv', parse_dates=['time']).sort_values('time').reset_index(drop=True)
development = full.copy()
development['forecast'] = np.where(full.current_severe == 0, full.forecast, reduced.forecast)
development['raw'] = -development.forecast / development.next_baseline
final = pd.read_csv(root / 'Probability Calibration/Refitted Predictions.csv', parse_dates=['time']).sort_values('time').reset_index(drop=True)
save(data, 'Eligible Hourly Samples')
save(development, 'Development Forecasts')
save(final, 'Final Predictions')
selection = json.loads((root / 'Representation Selection/Selection.json').read_text())
params = json.loads((root / 'Probability Calibration/Refit Parameters.json').read_text())
cal = development[development.time < '2025-05-01']
mapping = a.Mapping(cal)
scaler, logistic = probabilityFit(development, params['weighted'])
thresholds = {int(k): v for k, v in selection['thresholds'].items()}
pipeline = set(a.base.featureFamilies['in_transit_pipeline'])
keep = {'open_count', 'open_mass', 'open_age_med', 'open_age_p90', 'pipeline_to_baseline'}
reducedFeatures = [x for x in a.FEATURES if x not in pipeline or x in keep]
train = data[data.time < '2025-07-01']
later = data[data.time >= '2025-07-01']
fitted = {}
for label, features in [('Full', a.FEATURES), ('Reduced', reducedFeatures)]:
    for path in ['residual', 'direct']:
        for seed in a.SEEDS:
            forecast, learners = a.fit_component(train, later, path, seed, features)
            fitted[label, path, seed] = learners
            for state, learner in learners:
                if path == 'direct' or state == (0 if label == 'Full' else 1):
                    learner.save_model(str(models / (label + ' ' + path.title() + ' Seed ' + str(seed) + '.cbm')))
joblib.dump(dict(decision=mapping, probabilityScaler=scaler, probabilityModel=logistic, thresholds=thresholds, onsetFeatures=a.FEATURES, persistenceFeatures=reducedFeatures), models / 'Mappings and Feature Lists.joblib')
metadata = []
for name, scale, model in [('Decision', mapping.models[0][1].steps[0][1], mapping.models[0][1].steps[1][1]), ('Probability', scaler, logistic)]:
    metadata.append(dict(mapping=name, mean=float(scale.mean_[0]), standardDeviation=float(scale.scale_[0]), intercept=float(model.intercept_[0]), slope=float(model.coef_[0, 0])))
save(pd.DataFrame(metadata), 'Mapping Parameters')
save(pd.DataFrame([dict(state='Onset', threshold=thresholds[0]), dict(state='Persistence', threshold=thresholds[1])]), 'Decision Thresholds')
save(pd.DataFrame([dict(state=state, position=i + 1, feature=feature.replace('_', ' ')) for state, features in [('Onset', a.FEATURES), ('Persistence', reducedFeatures)] for i, feature in enumerate(features)]), 'Feature Lists')
def predict(frame):
    forecast = np.zeros(len(frame))
    for state, representation in [(0, 'Full'), (1, 'Reduced')]:
        mask = frame.current_severe.to_numpy() == state
        features = a.FEATURES if state == 0 else reducedFeatures
        values = []
        for path in ['residual', 'direct']:
            for seed in a.SEEDS:
                learners = fitted[representation, path, seed]
                model = next(model for st, model in learners if st is None or st == state)
                q = model.predict(frame.loc[mask, features])
                values.append(q + frame.loc[mask, 'expected_mass'].to_numpy() if path == 'residual' else q)
        if mask.any():
            forecast[mask] = np.mean(values, axis=0)
    q = frame[['time', 'y', 'current_severe', 'next_dest_ton', 'next_baseline']].copy()
    q['forecast'] = forecast
    q['raw'] = -forecast / q.next_baseline
    q['probability'] = logistic.predict_proba(scaler.transform(q[['raw']]))[:, 1]
    _, q['decision_score'] = mapping.predict(frame, q.raw)
    q['prediction'] = [int(score >= thresholds[int(state)]) for score, state in zip(q.decision_score, q.current_severe)]
    return q
rebuilt = predict(later)
components = {'SCPRDFE': final}
matchedMetrics = rows('SCPRDFE', final)
for name, path in [('Residual path', 'residual'), ('Direct path', 'direct')]:
    chunks = []
    for fold in range(4):
        if fold < 3:
            window = a.FOLDS[fold]
            tr = data[data.time < window['train_end']]
            va = data[(data.time >= window['valid_start']) & (data.time < window['valid_end'])]
        else:
            tr, va = train, later
        forecast = np.zeros(len(va))
        for state, features in [(0, a.FEATURES), (1, reducedFeatures)]:
            values = [a.fit_component(tr, va, path, seed, features)[0] for seed in a.SEEDS]
            mask = va.current_severe.to_numpy() == state
            forecast[mask] = np.mean(values, axis=0)[mask]
        q = va[['time', 'y', 'current_severe', 'next_dest_ton', 'next_baseline']].copy()
        q['forecast'] = forecast
        q['raw'] = -forecast / q.next_baseline
        chunks.append(q)
    q, _, _, _, _ = calibrated(pd.concat(chunks[:3]), chunks[3])
    components[name] = q
    matchedMetrics += rows(name, q)
    save(q, name + ' Predictions')
for name, filename in [('Full pipeline', 'primary SCPRDFE'), ('No pipeline', 'no pipeline Without pipeline'), ('Extra Trees', 'primary Extra Trees')]:
    q = pd.read_csv(root / 'Analysis' / (filename + ' Predictions.csv'), parse_dates=['time'])
    components[name] = q
    matchedMetrics += rows(name, q)
rules = pd.read_csv(root / 'Analysis/Rule Metrics.csv')
matchedMetrics += rules.to_dict('records')
current = data[['time', 'y', 'current_severe']].copy()
current['raw'] = -data.dest_ton / data.next_baseline
currentCal = current[(current.time >= '2025-01-01') & (current.time < '2025-05-01')]
currentValid = current[(current.time >= '2025-05-01') & (current.time < '2025-07-01')]
currentMapping = a.Mapping(currentCal)
_, currentDecision = currentMapping.predict(currentValid, currentValid.raw)
currentThresholds = {state: a.base.chooseThreshold(currentValid.loc[currentValid.current_severe == state, 'y'], currentDecision[currentValid.current_severe.to_numpy() == state]) for state in [0, 1]}
currentLater = current[current.time >= '2025-07-01'].copy()
currentLater['probability'], currentLater['decision_score'] = currentMapping.predict(currentLater, currentLater.raw)
currentLater['prediction'] = [int(score >= currentThresholds[int(state)]) for score, state in zip(currentLater.decision_score, currentLater.current_severe)]
matchedMetrics += rows('Calibrated current flow', currentLater)
components['Calibrated current flow'] = currentLater
save(currentLater, 'Calibrated Current Flow Predictions')
save(pd.DataFrame(matchedMetrics), 'Component and Rule Metrics')
_, corridor = a.base.loadTrips()
hourly = a.base.buildHourlyTable(corridor)
hourly = hourly[hourly.index.normalize() <= corridor.Start.max().normalize()]
delayMetrics = rows('Delay 0', final)
for delay in [15, 30, 60]:
    shifted = corridor.copy()
    shifted.Start += pd.Timedelta(minutes=delay)
    shifted.Close += pd.Timedelta(minutes=delay)
    hd = a.base.buildHourlyTable(shifted).reindex(hourly.index)
    hd.baseline = hourly.baseline
    hd = a.refresh(hd)
    inventory = a.pipeline(shifted, later.time, hd)
    dd = a.make_samples(hd, inventory).set_index('time').reindex(later.time).reset_index()
    dd.next_baseline = later.next_baseline.to_numpy()
    dd.y = later.y.to_numpy()
    dd.next_dest_ton = later.next_dest_ton.to_numpy()
    dd.pipeline_to_baseline = dd.expected_mass / dd.next_baseline
    dd[a.FEATURES] = dd[a.FEATURES].replace([np.inf, -np.inf], np.nan).fillna(0)
    q = predict(dd)
    delayMetrics += rows('Delay ' + str(delay), q)
    save(q, 'Delay ' + str(delay) + ' Predictions')
save(pd.DataFrame(delayMetrics), 'Reporting Delay Metrics')
reference = pd.read_csv(root / 'Reference Results/Refitted Predictions.csv', parse_dates=['time']).sort_values('time').reset_index(drop=True)
checks = {'Reference timestamps': final.time.equals(reference.time), 'Reference targets': np.array_equal(final.y, reference.y), 'Reference decisions': np.array_equal(final.prediction, reference.prediction), 'Reference forecasts': np.allclose(final.forecast, reference.forecast, rtol=1e-9, atol=1e-7), 'Reference probabilities': np.allclose(final.probability, reference.probability, rtol=1e-9, atol=1e-9), 'Saved model forecasts': np.allclose(rebuilt.forecast, final.forecast, rtol=1e-9, atol=1e-7), 'Saved model probabilities': np.allclose(rebuilt.probability, final.probability, rtol=1e-9, atol=1e-9), 'Saved model warnings': np.array_equal(rebuilt.prediction, final.prediction), 'Training observations': len(train) == 1260, 'Development forecasts': len(development) == 788, 'Later observations': len(final) == 256, 'Later severe outcomes': int(final.y.sum()) == 83, 'Selected onset': selection['selected_onset'] == 'SCPRDFE', 'Selected persistence': selection['selected_persistence'] == 'Reduced pipeline', 'Warning thresholds': thresholds == {0: .67, 1: .81}}
metrics = rows('SCPRDFE', final)
save(pd.DataFrame(metrics), 'Final Metrics')
save(pd.DataFrame([[126, 47], [10, 73]], columns=['Predicted adequate', 'Predicted severe']).assign(**{'Actual state': ['Adequate', 'Severe']})[['Actual state', 'Predicted adequate', 'Predicted severe']], 'Reference Confusion Matrix')
observed = metrics[0]
save(pd.DataFrame([dict(actual='Adequate', predictedAdequate=observed['tn'], predictedSevere=observed['fp']), dict(actual='Severe', predictedAdequate=observed['fn'], predictedSevere=observed['tp'])]), 'Confusion Matrix')
dateGroups = [np.flatnonzero(final.time.dt.normalize().to_numpy() == date) for date in final.time.dt.normalize().drop_duplicates()]
rng = np.random.default_rng(20261009)
intervals = []
paired = []
for length in [1, 3, 5]:
    values = {'Overall': [], 'Onset': [], 'Persistence': []}
    differences = {name: [] for name in components if name != 'SCPRDFE'}
    for rep in tqdm(range(2000), desc='Date blocks ' + str(length)):
        starts = rng.integers(0, len(dateGroups) - length + 1, int(np.ceil(len(dateGroups) / length)))
        dates = np.concatenate([np.arange(start, start + length) for start in starts])[:len(dateGroups)]
        indices = np.concatenate([dateGroups[date] for date in dates])
        q = final.iloc[indices]
        for state, label in [(None, 'Overall'), (0, 'Onset'), (1, 'Persistence')]:
            z = q if state is None else q[q.current_severe == state]
            if len(z):
                values[label].append(a.metric(z.y, z.prediction, z.raw, z.probability))
        if length == 3:
            main = values['Overall'][-1]
            for name in differences:
                alternative = components[name].sort_values('time').reset_index(drop=True).iloc[indices]
                comparison = a.metric(alternative.y, alternative.prediction, alternative.raw, alternative.probability)
                differences[name].append({metric: main[metric] - comparison[metric] for metric in ['auc', 'ap', 'f1', 'recall', 'brier']})
    for label, draws in values.items():
        frame = pd.DataFrame(draws)
        point = next(x for x in metrics if x['group'] == label)
        for metric in ['auc', 'ap', 'accuracy', 'balanced_accuracy', 'precision', 'recall', 'f1', 'brier']:
            series = frame[metric].dropna()
            intervals.append(dict(blockDates=length, group=label, metric=metric.replace('_', ' '), point=point[metric], lower=series.quantile(.025), upper=series.quantile(.975), validResamples=len(series)))
    if length == 3:
        for name, draws in differences.items():
            frame = pd.DataFrame(draws)
            alternative = components[name]
            comparison = a.metric(alternative.y, alternative.prediction, alternative.raw, alternative.probability)
            for metric in frame:
                series = frame[metric].dropna()
                paired.append(dict(comparator=name, metric=metric, difference=metrics[0][metric] - comparison[metric], lower=series.quantile(.025), upper=series.quantile(.975), validResamples=len(series)))
save(pd.DataFrame(intervals), 'Date Block Metric Intervals')
save(pd.DataFrame(paired), 'Paired Component Intervals')
burden = []
for state, label in [(None, 'Overall'), (0, 'Onset'), (1, 'Persistence')]:
    q = final if state is None else final[final.current_severe == state]
    dates = q.time.dt.normalize().nunique()
    burden.append(dict(group=label, monitoredDates=dates, warnings=int(q.prediction.sum()), falseAlarms=int(((q.prediction == 1) & (q.y == 0)).sum()), warningsPerDate=float(q.prediction.sum() / dates), falseAlarmsPerDate=float(((q.prediction == 1) & (q.y == 0)).sum() / dates)))
save(pd.DataFrame(burden), 'Warning Burden')
episodes = []
events = final[final.y == 1].copy()
number = ((events.time.diff() != pd.Timedelta(hours=1)) | (events.time.dt.normalize() != events.time.shift().dt.normalize())).cumsum()
for _, q in events.groupby(number):
    episodes.append(dict(firstTargetStart=str(q.time.iloc[0] + pd.Timedelta(hours=1)), hours=len(q), detectedAny=int(q.prediction.any()), detectedFirst=int(q.prediction.iloc[0])))
save(pd.DataFrame(episodes), 'Observed Episodes')
bins = []
for number, indices in enumerate(np.array_split(np.argsort(final.probability.to_numpy()), 6), 1):
    q = final.iloc[indices]
    bins.append(dict(bin=number, observations=len(q), meanProbability=q.probability.mean(), observedFrequency=q.y.mean()))
save(pd.DataFrame(bins), 'Probability Bins')
for section, filename, output in [('Representation Selection', 'Development Selection.csv', 'Representation Candidate Selection'), ('Learner Comparison', 'Development Selection.csv', 'Learner Candidate Selection'), ('Probability Calibration', 'Refit Development Selection.csv', 'Probability Weight Selection')]:
    save(pd.read_csv(root / section / filename), output)
report = {'Checks': {k: bool(v) for k, v in checks.items()}, 'All checks passed': all(checks.values()), 'Evaluation description': 'Chronological comparative evaluation', 'Independent untouched test claimed': False, 'Maximum forecast difference': float(np.max(np.abs(final.forecast - reference.forecast))), 'Maximum probability difference': float(np.max(np.abs(final.probability - reference.probability))), 'Final metrics': metrics}
(out / 'Verification Report.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2), flush=True)
if not report['All checks passed']:
    raise RuntimeError('Reproduction differs from the archived final run. Inspect Verification Report.json')
