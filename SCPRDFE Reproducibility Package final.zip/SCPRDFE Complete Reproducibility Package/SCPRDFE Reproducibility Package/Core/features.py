from pathlib import Path
import json
import math
import shutil
import zipfile
import warnings
import joblib
import numpy as np
import pandas as pd
from tqdm.auto import tqdm
from catboost import CatBoostRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, average_precision_score, accuracy_score, balanced_accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import os
dataPath = Path(os.environ.get('SCPRDFE DATA', str(Path(__file__).resolve().parents[1] / 'Annexure II.xlsx')))
seeds = [17, 42, 91]
eligibleHours = [8, 9, 10, 11, 14, 15]
severeThreshold = 0.5
halfLifeDays = 120.0
weightFloor = 0.03
featureFamilies = {'fleet_activity': ['start_vehicles', 'close_vehicles', 'vehicle_hhi', 'starts_per_vehicle', 'closes_per_vehicle'], 'journey_dynamics': ['dur_mean', 'dur_med', 'dur_p90', 'dur_med_lag1', 'dur_med_lag2'], 'material_reconciliation': ['discrep_mean', 'discrep_sum'], 'in_transit_pipeline': ['pipeline_to_baseline', 'open_mass_lt30', 'open_vehicles', 'open_mass_per_vehicle', 'open_mass', 'open_age_med', 'open_lt30', 'open_mass_30_60', 'open_count', 'open_mass_60_120', 'open_30_60', 'open_age_p90', 'open_mass_gt120', 'open_gt120', 'open_60_120'], 'subhour_momentum': ['starts_last30_ratio', 'closes_last30_ratio', 'source_last30', 'starts_last30', 'closes_last30', 'starts_first30', 'dest_last30', 'source_first30', 'dest_first30', 'source_momentum', 'close_momentum', 'closes_first30', 'start_momentum', 'dest_momentum'], 'history_change': ['neg_cusum_pos', 'dest_ton_lag2', 'closes_lag2', 'ratio_pos_ewm3', 'ratio_pos_delta1', 'ratio_pos_lag2', 'ratio_pos_ewm6', 'source_ton_lag1', 'source_ton_lag2', 'ratio_pos_lag1', 'starts_lag2', 'start_vehicles_lag2', 'start_vehicles_lag1', 'closes_lag1', 'starts_lag1', 'dest_ton_lag1'], 'calendar_position': ['month', 'month_cos', 'dow_sin', 'hod_cos', 'dow', 'hod', 'hod_sin', 'dow_cos', 'month_sin'], 'absolute_flow_state': ['source_ton', 'starts', 'dest_ton', 'closes', 'ratio_pos', 'day_cum_dest', 'day_cum_source', 'cum_ratio'], 'permit_context': ['start_permits', 'permit_hhi'], 'current_markov_state': ['current_severe']}
featureColumns = []
expectedFeatureOrder = ['month', 'starts_last30_ratio', 'ratio_pos', 'pipeline_to_baseline', 'month_cos', 'closes_last30_ratio', 'source_ton', 'starts', 'source_last30', 'open_mass_lt30', 'start_vehicles', 'open_vehicles', 'neg_cusum_pos', 'dest_ton_lag2', 'discrep_mean', 'closes_lag2', 'ratio_pos_ewm3', 'starts_last30', 'dur_med_lag2', 'dest_ton', 'open_mass_per_vehicle', 'closes_last30', 'ratio_pos_delta1', 'cum_ratio', 'dow_sin', 'starts_first30', 'dest_last30', 'source_first30', 'open_mass', 'open_age_med', 'closes', 'dest_momentum', 'ratio_pos_lag2', 'ratio_pos_ewm6', 'discrep_sum', 'open_lt30', 'day_cum_dest', 'dur_med', 'dest_first30', 'dur_p90', 'dur_mean', 'open_mass_30_60', 'source_ton_lag1', 'source_ton_lag2', 'hod_cos', 'open_count', 'dow', 'ratio_pos_lag1', 'source_momentum', 'starts_lag2', 'close_momentum', 'dur_med_lag1', 'close_vehicles', 'day_cum_source', 'hod', 'current_severe', 'dest_ton_lag1', 'hod_sin', 'open_mass_60_120', 'start_vehicles_lag2', 'open_30_60', 'start_vehicles_lag1', 'closes_lag1', 'start_permits', 'dow_cos', 'vehicle_hhi', 'open_age_p90', 'open_mass_gt120', 'permit_hhi', 'starts_lag1', 'open_gt120', 'month_sin', 'open_60_120', 'closes_per_vehicle', 'closes_first30', 'start_momentum', 'starts_per_vehicle']
featureColumns = expectedFeatureOrder.copy()

def safeDivide(numerator, denominator, defaultValue=0.0):
    numeratorArray = np.asarray(numerator, dtype=float)
    denominatorArray = np.asarray(denominator, dtype=float)
    result = np.full(np.broadcast(numeratorArray, denominatorArray).shape, defaultValue, dtype=float)
    np.divide(numeratorArray, denominatorArray, out=result, where=np.isfinite(denominatorArray) & (np.abs(denominatorArray) > 1e-12))
    return result

def concentrationIndex(values):
    counts = pd.Series(values).dropna().astype(str).value_counts()
    if len(counts) == 0:
        return 0.0
    shares = counts.to_numpy(dtype=float) / counts.sum()
    return float(np.sum(shares ** 2))

def loadTrips():
    if not dataPath.exists():
        raise FileNotFoundError('Dataset not found at ' + str(dataPath))
    sheetNames = pd.ExcelFile(dataPath).sheet_names
    sheetName = 'Royalty' if 'Royalty' in sheetNames else sheetNames[0]
    raw = pd.read_excel(dataPath, sheet_name=sheetName, header=1)
    renameMap = {'Permit Number': 'Permit', 'Vehicle No/Barge name': 'Vehicle', 'Source Location': 'Source', 'Trip start Date -Time': 'Start', 'Loaded qty @Source': 'SourceQty', 'Destination Location': 'Destination', 'Trip Close Date -Time': 'Close', 'Loaded qty @Destination': 'DestinationQty'}
    raw = raw.rename(columns=renameMap)
    required = ['Permit', 'Vehicle', 'Source', 'Start', 'SourceQty', 'Destination', 'Close', 'DestinationQty']
    missing = [column for column in required if column not in raw.columns]
    if missing:
        raise ValueError('Missing required columns: ' + ', '.join(missing))
    raw['Start'] = pd.to_datetime(raw['Start'], errors='coerce')
    raw['Close'] = pd.to_datetime(raw['Close'], errors='coerce')
    raw['SourceQty'] = pd.to_numeric(raw['SourceQty'], errors='coerce')
    raw['DestinationQty'] = pd.to_numeric(raw['DestinationQty'], errors='coerce')
    usable = raw.dropna(subset=['Start', 'Close', 'SourceQty', 'DestinationQty']).copy()
    usable['Duration'] = (usable['Close'] - usable['Start']).dt.total_seconds() / 60.0
    usable = usable[usable['Duration'].ge(0)].copy()
    sourceText = usable['Source'].astype(str).str.lower().str.replace('\\s+', ' ', regex=True)
    destinationText = usable['Destination'].astype(str).str.lower().str.replace('\\s+', ' ', regex=True)
    corridorMask = sourceText.str.contains('bicholim mineral block', na=False) & destinationText.str.contains('sarmanas jetty', na=False)
    corridor = usable.loc[corridorMask].copy()
    corridor = corridor.sort_values(['Start', 'Close']).reset_index(drop=True)
    print('Workbook:', dataPath)
    print('Worksheet:', sheetName)
    print('Rows in source table:', f'{len(raw):,}')
    print('Usable movement records:', f'{len(usable):,}')
    print('Bicholim Mineral Block I to Sarmanas Jetty records:', f'{len(corridor):,}')
    print('Date range:', corridor['Start'].min(), 'to', corridor['Close'].max())
    return (usable, corridor)

def aggregateHalfHour(data, timeColumn, quantityColumn, prefix):
    work = data[[timeColumn, quantityColumn]].copy()
    work['hour'] = work[timeColumn].dt.floor('h')
    work['half'] = np.where(work[timeColumn].dt.minute < 30, 'first30', 'last30')
    countTable = work.groupby(['hour', 'half']).size().unstack(fill_value=0)
    quantityTable = work.groupby(['hour', 'half'])[quantityColumn].sum().unstack(fill_value=0)
    result = pd.DataFrame(index=countTable.index.union(quantityTable.index))
    result[f'{prefix}_first30'] = countTable.get('first30', pd.Series(0, index=result.index)).reindex(result.index, fill_value=0)
    result[f'{prefix}_last30'] = countTable.get('last30', pd.Series(0, index=result.index)).reindex(result.index, fill_value=0)
    result[f'{prefix}_quantity_first30'] = quantityTable.get('first30', pd.Series(0.0, index=result.index)).reindex(result.index, fill_value=0)
    result[f'{prefix}_quantity_last30'] = quantityTable.get('last30', pd.Series(0.0, index=result.index)).reindex(result.index, fill_value=0)
    return result

def buildHourlyTable(corridor):
    startData = corridor.copy()
    closeData = corridor.copy()
    startData['hour'] = startData['Start'].dt.floor('h')
    closeData['hour'] = closeData['Close'].dt.floor('h')
    startAgg = startData.groupby('hour').agg(source_ton=('SourceQty', 'sum'), starts=('Permit', 'size'), start_vehicles=('Vehicle', 'nunique'), start_permits=('Permit', 'nunique'))
    closeAgg = closeData.groupby('hour').agg(dest_ton=('DestinationQty', 'sum'), closes=('Permit', 'size'), close_vehicles=('Vehicle', 'nunique'), dur_mean=('Duration', 'mean'), dur_med=('Duration', 'median'), dur_p90=('Duration', lambda series: float(np.nanpercentile(series, 90)) if len(series) else np.nan), discrep_mean=('SourceQty', lambda series: 0.0), discrep_sum=('SourceQty', lambda series: 0.0))
    closeDiscrepancy = closeData.assign(discrepancy=closeData['SourceQty'] - closeData['DestinationQty']).groupby('hour')['discrepancy'].agg(['mean', 'sum'])
    closeAgg['discrep_mean'] = closeDiscrepancy['mean']
    closeAgg['discrep_sum'] = closeDiscrepancy['sum']
    startHalf = aggregateHalfHour(startData, 'Start', 'SourceQty', 'starts')
    closeHalf = aggregateHalfHour(closeData, 'Close', 'DestinationQty', 'closes')
    firstHour = min(startData['hour'].min(), closeData['hour'].min()).floor('D')
    lastHour = max(startData['hour'].max(), closeData['hour'].max()).ceil('D')
    fullIndex = pd.date_range(firstHour, lastHour, freq='h', inclusive='left')
    hourly = pd.DataFrame(index=fullIndex)
    hourly.index.name = 'time'
    hourly = hourly.join(startAgg, how='left').join(closeAgg, how='left').join(startHalf, how='left').join(closeHalf, how='left')
    zeroColumns = ['source_ton', 'starts', 'start_vehicles', 'start_permits', 'dest_ton', 'closes', 'close_vehicles', 'discrep_mean', 'discrep_sum', 'starts_first30', 'starts_last30', 'starts_quantity_first30', 'starts_quantity_last30', 'closes_first30', 'closes_last30', 'closes_quantity_first30', 'closes_quantity_last30']
    for column in zeroColumns:
        if column not in hourly.columns:
            hourly[column] = 0.0
        hourly[column] = hourly[column].fillna(0.0)
    hourly['date'] = hourly.index.normalize()
    hourly['hod'] = hourly.index.hour.astype(int)
    hourly['dow'] = hourly.index.dayofweek.astype(int)
    hourly['month'] = hourly.index.month.astype(int)
    hourly['baseline'] = np.nan
    for hourValue in range(24):
        positions = np.where(hourly['hod'].to_numpy() == hourValue)[0]
        positiveHistory = []
        for position in positions:
            if len(positiveHistory) >= 10:
                hourly.iloc[position, hourly.columns.get_loc('baseline')] = float(np.median(positiveHistory))
            currentValue = float(hourly.iloc[position]['dest_ton'])
            if currentValue > 0:
                positiveHistory.append(currentValue)
    hourly['ratio_pos'] = safeDivide(hourly['dest_ton'], hourly['baseline'], np.nan)
    hourly['ratio_pos'] = pd.Series(hourly['ratio_pos'], index=hourly.index).clip(lower=0)
    hourly['current_severe'] = np.where(hourly['baseline'].notna(), (hourly['ratio_pos'] < severeThreshold).astype(int), np.nan)
    hourly['source_first30'] = hourly['starts_quantity_first30']
    hourly['source_last30'] = hourly['starts_quantity_last30']
    hourly['dest_first30'] = hourly['closes_quantity_first30']
    hourly['dest_last30'] = hourly['closes_quantity_last30']
    hourly['starts_last30_ratio'] = safeDivide(hourly['starts_last30'], hourly['starts'], 0.0)
    hourly['closes_last30_ratio'] = safeDivide(hourly['closes_last30'], hourly['closes'], 0.0)
    hourly['start_momentum'] = hourly['starts_last30'] - hourly['starts_first30']
    hourly['close_momentum'] = hourly['closes_last30'] - hourly['closes_first30']
    hourly['source_momentum'] = hourly['source_last30'] - hourly['source_first30']
    hourly['dest_momentum'] = hourly['dest_last30'] - hourly['dest_first30']
    hourly['starts_per_vehicle'] = safeDivide(hourly['starts'], hourly['start_vehicles'], 0.0)
    hourly['closes_per_vehicle'] = safeDivide(hourly['closes'], hourly['close_vehicles'], 0.0)
    startVehicleHhi = startData.groupby('hour')['Vehicle'].apply(concentrationIndex)
    startPermitHhi = startData.groupby('hour')['Permit'].apply(concentrationIndex)
    hourly['vehicle_hhi'] = startVehicleHhi.reindex(hourly.index).fillna(0.0)
    hourly['permit_hhi'] = startPermitHhi.reindex(hourly.index).fillna(0.0)
    hourly['day_cum_source'] = hourly.groupby('date')['source_ton'].cumsum()
    hourly['day_cum_dest'] = hourly.groupby('date')['dest_ton'].cumsum()
    hourly['day_cum_baseline'] = hourly.groupby('date')['baseline'].cumsum()
    hourly['cum_ratio'] = safeDivide(hourly['day_cum_dest'], hourly['day_cum_baseline'], 0.0)
    for column in ['source_ton', 'dest_ton', 'starts', 'closes', 'start_vehicles', 'ratio_pos', 'dur_med']:
        hourly[f'{column}_lag1'] = hourly[column].shift(1)
        hourly[f'{column}_lag2'] = hourly[column].shift(2)
    hourly['ratio_pos_delta1'] = hourly['ratio_pos'] - hourly['ratio_pos_lag1']
    hourly['ratio_pos_ewm3'] = hourly['ratio_pos'].ewm(span=3, adjust=False, ignore_na=True).mean()
    hourly['ratio_pos_ewm6'] = hourly['ratio_pos'].ewm(span=6, adjust=False, ignore_na=True).mean()
    deterioration = []
    running = 0.0
    previousDate = None
    for timeValue, ratioValue in hourly['ratio_pos'].items():
        currentDate = pd.Timestamp(timeValue).normalize()
        if previousDate is not None and currentDate != previousDate:
            running = 0.0
        if np.isfinite(ratioValue):
            running = max(0.0, running + 1.0 - float(ratioValue))
        deterioration.append(running)
        previousDate = currentDate
    hourly['neg_cusum_pos'] = deterioration
    hourly['hod_sin'] = np.sin(2.0 * np.pi * hourly['hod'] / 24.0)
    hourly['hod_cos'] = np.cos(2.0 * np.pi * hourly['hod'] / 24.0)
    hourly['dow_sin'] = np.sin(2.0 * np.pi * hourly['dow'] / 7.0)
    hourly['dow_cos'] = np.cos(2.0 * np.pi * hourly['dow'] / 7.0)
    hourly['month_sin'] = np.sin(2.0 * np.pi * (hourly['month'] - 1) / 12.0)
    hourly['month_cos'] = np.cos(2.0 * np.pi * (hourly['month'] - 1) / 12.0)
    return hourly

def recencyWeights(times):
    timeSeries = pd.to_datetime(pd.Series(times))
    reference = timeSeries.max()
    ageDays = (reference - timeSeries).dt.total_seconds().to_numpy() / 86400.0
    weights = np.exp(-(np.log(2.0) * ageDays) / halfLifeDays)
    return np.maximum(weightFloor, weights)

def rollingFoldDefinitions():
    return [{'fold': 0, 'train_end': pd.Timestamp('2025-01-01'), 'valid_start': pd.Timestamp('2025-01-01'), 'valid_end': pd.Timestamp('2025-03-01'), 'label': 'January to February 2025'}, {'fold': 1, 'train_end': pd.Timestamp('2025-03-01'), 'valid_start': pd.Timestamp('2025-03-01'), 'valid_end': pd.Timestamp('2025-05-01'), 'label': 'March to April 2025'}, {'fold': 2, 'train_end': pd.Timestamp('2025-05-01'), 'valid_start': pd.Timestamp('2025-05-01'), 'valid_end': pd.Timestamp('2025-07-01'), 'label': 'May to June 2025'}]

def chooseThreshold(yTrue, decisionScore):
    best = None
    for thresholdValue in np.round(np.arange(0.01, 1.0, 0.01), 2):
        predicted = (decisionScore >= thresholdValue).astype(int)
        balancedValue = balanced_accuracy_score(yTrue, predicted)
        f1Value = f1_score(yTrue, predicted, zero_division=0)
        recallValue = recall_score(yTrue, predicted, zero_division=0)
        precisionValue = precision_score(yTrue, predicted, zero_division=0)
        if balancedValue + f1Value > 0:
            harmonicValue = 2.0 * balancedValue * f1Value / (balancedValue + f1Value)
        else:
            harmonicValue = 0.0
        candidate = (harmonicValue, recallValue, precisionValue, -abs(thresholdValue - 0.5), thresholdValue)
        if best is None or candidate > best:
            best = candidate
    return float(best[-1])
