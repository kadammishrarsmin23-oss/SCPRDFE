from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'Files SHA256.json').read_text())
failed = []
for relative, expected in manifest.items():
    path = root / relative
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        failed.append(relative)
if failed:
    raise RuntimeError('File verification failed: ' + ', '.join(failed))
print('Verified ' + str(len(manifest)) + ' source and reference files')
