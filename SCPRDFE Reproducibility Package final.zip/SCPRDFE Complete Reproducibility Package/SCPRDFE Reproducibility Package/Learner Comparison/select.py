from pathlib import Path
import sys, json
import pandas as pd, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import mean_absolute_error
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'Analysis'))
import analyse as a
O = ROOT / 'Learner Comparison'
names = ['Shallow regularized', 'Moderate regularized', 'Deep regularized', 'Robust residual', 'Histogram ensemble']
paths = {}
for n in names:
    paths[n] = (O / (n + ' ' + n + ' Development.csv'), O / (n + ' ' + n + ' Predictions.csv'))
x = pd.read_csv(ROOT / 'Analysis/primary SCPRDFE Development.csv', parse_dates=['time']).sort_values('time').reset_index(drop=True)
y = pd.read_csv(ROOT / 'Representation Selection/refinement Reduced pipeline Development.csv', parse_dates=['time']).sort_values('time').reset_index(drop=True)
assert x.time.equals(y.time)
x['forecast'] = np.where(x.current_severe == 0, x.forecast, y.forecast)
x['raw'] = -x.forecast / x.next_baseline
pbase = pd.read_csv(ROOT / 'Probability Calibration/Refitted Predictions.csv', parse_dates=['time']).sort_values('time').reset_index(drop=True)
devs = {n: pd.read_csv(paths[n][0], parse_dates=['time']).sort_values('time').reset_index(drop=True) for n in names}
devs['SCPRDFE reference'] = x
assert all((v.time.equals(x.time) and v.y.equals(x.y) for v in devs.values()))

def probfit(z):
    sc = StandardScaler().fit(z[['raw']])
    m = LogisticRegression(C=1, max_iter=5000, solver='lbfgs', random_state=0)
    m.fit(sc.transform(z[['raw']]), z.y, sample_weight=a.base.recencyWeights(z.time))
    return (sc, m)

def threshold(y, s, minrecall=0):
    grid = np.round(np.arange(0.01, 1, 0.01), 2)
    y = np.asarray(y, int)
    p = np.asarray(s)[:, None] >= grid
    tp = (p & (y[:, None] == 1)).sum(0)
    fp = (p & (y[:, None] == 0)).sum(0)
    fn = y.sum() - tp
    tn = len(y) - y.sum() - fp
    rec = tp / max(1, y.sum())
    spe = tn / max(1, len(y) - y.sum())
    ba = (rec + spe) / 2
    f1 = 2 * tp / np.maximum(1, 2 * tp + fp + fn)
    precision = tp / np.maximum(1, tp + fp)
    h = 2 * ba * f1 / np.maximum(1e-12, ba + f1)
    i = max(range(len(grid)), key=lambda i: (rec[i] >= minrecall - 1e-12, h[i], rec[i], precision[i], -abs(grid[i] - 0.5), grid[i]))
    return float(grid[i])
cal = x[x.time < '2025-05-01']
valid = x[x.time >= '2025-05-01']
mapping = a.Mapping(cal)
_, dec = mapping.predict(valid, valid.raw)
floors = {}
for st in [0, 1]:
    mask = valid.current_severe.to_numpy() == st
    th = threshold(valid.loc[mask, 'y'], dec[mask])
    floors[st] = a.metric(valid.loc[mask, 'y'], dec[mask] >= th, dec[mask])['recall']
rows = []
params = {}
selecteddev = {}
for onset in devs:
    for persistence in devs:
        z = x.copy()
        z['forecast'] = np.where(z.current_severe == 0, devs[onset].forecast, devs[persistence].forecast)
        z['raw'] = -z.forecast / z.next_baseline
        c = z[z.time < '2025-05-01']
        v = z[z.time >= '2025-05-01']
        mapping = a.Mapping(c)
        _, dec = mapping.predict(v, v.raw)
        sc, m = probfit(c)
        pro = m.predict_proba(sc.transform(v[['raw']]))[:, 1]
        pred = np.zeros(len(v), int)
        ths = {}
        branch = []
        for st in [0, 1]:
            mask = v.current_severe.to_numpy() == st
            ths[st] = threshold(v.loc[mask, 'y'], dec[mask], floors[st])
            pred[mask] = dec[mask] >= ths[st]
            mt = a.metric(v.loc[mask, 'y'], pred[mask], pro[mask], pro[mask])
            branch.append(2 * mt['balanced_accuracy'] * mt['f1'] / max(1e-12, mt['balanced_accuracy'] + mt['f1']))
        mt = a.metric(v.y, pred, pro, pro)
        key = onset + ' | ' + persistence
        rows.append(dict(candidate=key, onset=onset, persistence=persistence, selection_score=float(np.mean(branch)), mae=mean_absolute_error(v.next_dest_ton, v.forecast), **mt))
        params[key] = (mapping, ths)
        selecteddev[key] = z
rank = pd.DataFrame(rows).sort_values(['selection_score', 'auc'], ascending=False)
baseline = rank[rank.candidate == 'SCPRDFE reference | SCPRDFE reference'].iloc[0]
rank['eligible'] = (rank.brier <= baseline.brier + 1e-12) & (rank.mae <= baseline.mae + 1e-12) & (rank.recall >= baseline.recall - 1e-12)
rank.to_csv(O / 'Development Selection.csv', index=False)
best = rank[rank.eligible].iloc[0]
mapping, ths = params[best.candidate]
dev = selecteddev[best.candidate]
dev.to_csv(O / 'Selected Development.csv', index=False)

def later(n):
    return pbase.copy() if n == 'SCPRDFE reference' else pd.read_csv(paths[n][1], parse_dates=['time']).sort_values('time').reset_index(drop=True)
x0 = later(best.onset)
x1 = later(best.persistence)
assert x0.time.equals(x1.time) and x0.time.equals(pbase.time)
p = x0.copy()
p['forecast'] = np.where(p.current_severe == 0, x0.forecast, x1.forecast)
p['raw'] = -p.forecast / p.next_baseline
_, p['decision_score'] = mapping.predict(p, p.raw)
p['prediction'] = [int(v >= ths[int(st)]) for v, st in zip(p.decision_score, p.current_severe)]
assert dev.time.max() + pd.Timedelta(hours=2) < pd.Timestamp('2025-07-01')
sc, m = probfit(dev)
p['probability'] = m.predict_proba(sc.transform(p[['raw']]))[:, 1]
p.to_csv(O / 'Selected Predictions.csv', index=False)
config = dict(onset=best.onset, persistence=best.persistence, thresholds=ths, candidates=len(rank), development_score=float(best.selection_score), baseline_development_score=float(baseline.selection_score), reference_recall_floors=floors, calibration=dict(mean=float(sc.mean_[0]), scale=float(sc.scale_[0]), intercept=float(m.intercept_[0]), slope=float(m.coef_[0, 0])), independent_test=False)
(O / 'Selection.json').write_text(json.dumps(config, indent=2))
metrics = []
for label, v in [('SCPRDFE reference', pbase), ('Regularization candidate', p)]:
    for st, group in [(None, 'Overall'), (0, 'Onset'), (1, 'Persistence')]:
        q = v if st is None else v[v.current_severe == st]
        metrics.append(dict(model=label, group=group, **a.metric(q.y, q.prediction, q.raw, q.probability), mae=mean_absolute_error(q.next_dest_ton, q.forecast)))
pd.DataFrame(metrics).to_csv(O / 'Comparison Metrics.csv', index=False)
print(json.dumps(config, indent=2), flush=True)
print(pd.DataFrame(metrics).to_string(index=False), flush=True)
rng = np.random.default_rng(20261013)
dates = p.time.dt.normalize()
unique = dates.drop_duplicates().to_numpy()
groups = [np.where(dates.to_numpy() == dt)[0] for dt in unique]
changes = []
for i in range(2000):
    ix = []
    while len(ix) < len(groups):
        start = rng.integers(len(groups))
        ix.extend([(start + j) % len(groups) for j in range(3)])
    inds = np.concatenate([groups[j] for j in ix[:len(groups)]])
    u = p.iloc[inds]
    v = pbase.iloc[inds]
    if u.y.nunique() < 2:
        continue
    um = a.metric(u.y, u.prediction, u.raw, u.probability)
    vm = a.metric(v.y, v.prediction, v.raw, v.probability)
    changes.append({k: um[k] - vm[k] for k in ['auc', 'f1', 'accuracy', 'recall', 'brier']} | {'mae': mean_absolute_error(u.next_dest_ton, u.forecast) - mean_absolute_error(v.next_dest_ton, v.forecast)})
b = pd.DataFrame(changes)
(O / 'Paired Intervals.json').write_text(json.dumps({c: [float(b[c].quantile(0.025)), float(b[c].quantile(0.975))] for c in b}, indent=2))
