from pathlib import Path
import sys, json, hashlib
import numpy as np, pandas as pd
from catboost import CatBoostRegressor
from sklearn.ensemble import HistGradientBoostingRegressor
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'Analysis'))
import analyse as a
O = ROOT / 'Learner Comparison'
a.OUT = O
d = pd.read_csv(ROOT / 'Analysis/Cutoff Samples.csv', parse_dates=['time'])
CONFIGS = [('Shallow regularized', 2, 500, 15, 'catboost'), ('Moderate regularized', 3, 400, 15, 'catboost'), ('Deep regularized', 5, 350, 15, 'catboost'), ('Robust residual', 4, 350, 10, 'huber'), ('Histogram ensemble', 3, 260, 10, 'histogram')]
original_fp = a.cache_fingerprint
active = None

def fingerprint(*args, **kwargs):
    return hashlib.sha256((original_fp(*args, **kwargs) + json.dumps(active) + Path(__file__).read_text()).encode()).hexdigest()
a.cache_fingerprint = fingerprint

def fit(tr, va, kind, seed, features, loss='mixed', weighted=True, remember=False):
    name, depth, iterations, l2, family = active
    out = np.zeros(len(va))
    models = []
    for st in [0, 1] if kind == 'residual' else [None]:
        z = tr if st is None else tr[tr.current_severe == st]
        mask = np.ones(len(va), bool) if st is None else va.current_severe.to_numpy() == st
        y = z.next_dest_ton - z.expected_mass if kind == 'residual' else z.next_dest_ton
        if family == 'histogram':
            m = HistGradientBoostingRegressor(loss='quantile' if st == 1 else 'squared_error', quantile=0.2 if st == 1 else None, max_iter=iterations, max_leaf_nodes=7, max_depth=depth, min_samples_leaf=15, l2_regularization=l2, learning_rate=0.035, early_stopping=False, random_state=seed)
        else:
            objective = 'Quantile:alpha=0.20' if st == 1 else 'Huber:delta=100' if family == 'huber' else 'RMSE'
            m = CatBoostRegressor(iterations=iterations, depth=depth, learning_rate=0.035, l2_leaf_reg=l2, loss_function=objective, random_seed=seed, thread_count=4, verbose=False, allow_writing_files=False)
        m.fit(z[features], y, sample_weight=a.base.recencyWeights(z.time))
        q = m.predict(va.loc[mask, features])
        out[mask] = q + va.loc[mask, 'expected_mass'].to_numpy() if kind == 'residual' else q
        models.append((st, m))
    return (out, models)
a.fit_component = fit
for active in CONFIGS:
    name = active[0]
    print('Starting ' + name, flush=True)
    a.run_model(name, d, dataset=name, features=a.FEATURES)
    print('Completed ' + name, flush=True)
