from pathlib import Path
import importlib.util, json, time, hashlib, warnings
import numpy as np, pandas as pd
from catboost import CatBoostRegressor, CatBoostClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, brier_score_loss, mean_absolute_error, mean_squared_error
warnings.filterwarnings('ignore')
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'Analysis'
spec = importlib.util.spec_from_file_location('base', ROOT / 'Core/features.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
FEATURES = base.featureColumns
SEEDS = [17, 42, 91]
FOLDS = base.rollingFoldDefinitions()
CACHE = {}
FINAL = {}

def refresh(h):
    h = h.copy()
    h['ratio_pos'] = base.safeDivide(h.dest_ton, h.baseline, np.nan)
    h['current_severe'] = np.where(h.baseline.notna(), (h.ratio_pos < 0.5).astype(int), np.nan)
    h['day_cum_source'] = h.groupby('date').source_ton.cumsum()
    h['day_cum_dest'] = h.groupby('date').dest_ton.cumsum()
    h['day_cum_baseline'] = h.groupby('date').baseline.cumsum()
    h['cum_ratio'] = base.safeDivide(h.day_cum_dest, h.day_cum_baseline)
    for c in ['source_ton', 'dest_ton', 'starts', 'closes', 'start_vehicles', 'ratio_pos', 'dur_med']:
        h[c + '_lag1'] = h[c].shift(1)
        h[c + '_lag2'] = h[c].shift(2)
    h['ratio_pos_delta1'] = h.ratio_pos - h.ratio_pos_lag1
    for k in [3, 6]:
        h['ratio_pos_ewm' + str(k)] = h.ratio_pos.ewm(span=k, adjust=False, ignore_na=True).mean()
    run = 0.0
    prev = None
    vals = []
    for t, r in h.ratio_pos.items():
        if t.normalize() != prev:
            run = 0.0
        if np.isfinite(r):
            run = max(0.0, run + 1 - r)
        vals.append(run)
        prev = t.normalize()
    h['neg_cusum_pos'] = vals
    return h

def pipeline(trips, times, h):
    a = trips.sort_values('Close')
    st = a.Start.astype('int64').to_numpy()
    cl = a.Close.astype('int64').to_numpy()
    mass = a.SourceQty.to_numpy(float)
    dst = a.DestinationQty.to_numpy(float)
    dur = a.Duration.to_numpy(float)
    vehicle = a.Vehicle.astype(str).to_numpy()
    rows = []
    for t in times:
        cutoff = t + pd.Timedelta(hours=1)
        cn = cutoff.value
        end = (cutoff + pd.Timedelta(hours=1)).value
        history = dur[cl < cn]
        hist = np.sort(history)
        short = np.sort(history[history <= 1440])
        openmask = (st < cn) & (cl >= cn)
        ages = (cn - st[openmask]) / 60000000000.0
        om = mass[openmask]
        ov = vehicle[openmask]
        bands = [ages < 30, (ages >= 30) & (ages < 60), (ages >= 60) & (ages < 120), ages >= 120]
        reprs = [15, 45, 90, 180]

        def prob(x, z):
            lo = np.searchsorted(z, x, side='right')
            hi = np.searchsorted(z, np.asarray(x) + 60, side='right')
            return (hi - lo + 1) / (len(z) - lo + 2)
        probs = prob(np.array(reprs), hist)
        e = sum((om[b].sum() * p for b, p in zip(bands, probs)))
        ea = (om * prob(ages, hist)).sum()
        es = sum((om[b].sum() * p for b, p in zip(bands, prob(np.array(reprs), short))))
        r = {'time': t, 'expected_mass': e, 'expected_actual_age': ea, 'expected_duration_24h': es, 'pipeline_to_baseline': base.safeDivide(e, h.baseline.get(cutoff, np.nan)).item(), 'open_count': len(ages), 'open_mass': om.sum(), 'open_vehicles': len(set(ov)), 'open_mass_per_vehicle': om.sum() / max(1, len(set(ov))), 'open_age_med': np.median(ages) if len(ages) else 0, 'open_age_p90': np.percentile(ages, 90) if len(ages) else 0, 'open_target_ton': dst[openmask & (cl < end)].sum()}
        for name, b in zip(['lt30', '30_60', '60_120', 'gt120'], bands):
            r['open_' + name] = int(b.sum())
            r['open_mass_' + name] = om[b].sum()
        rows.append(r)
    return pd.DataFrame(rows).set_index('time')

def make_samples(h, pi, boundary=0.5):
    d = h.join(pi, how='inner')
    d['time'] = d.index
    d['next_time'] = d.time + pd.Timedelta(hours=1)
    f = h[['dest_ton', 'baseline', 'ratio_pos']].rename(columns={'dest_ton': 'next_dest_ton', 'baseline': 'next_baseline', 'ratio_pos': 'next_ratio'})
    d = d.join(f, on='next_time')
    d = d[d.next_baseline.notna()].copy()
    d['y'] = (d.next_ratio < boundary).astype(int)
    d['current_severe'] = (d.ratio_pos < boundary).astype(int)
    d['residual_target'] = d.next_dest_ton - d.expected_mass
    d['day_starts'] = h.groupby('date').starts.cumsum().reindex(d.index)
    d['day_closes'] = h.groupby('date').closes.cumsum().reindex(d.index)
    d['eligible_cutoff'] = (d.day_starts > 0) | (d.day_closes > 0) | (d.open_count > 0)
    d[FEATURES] = d[FEATURES].replace([np.inf, -np.inf], np.nan).fillna(0)
    return d.reset_index(drop=True)

def metric(y, pred, score, prob=None):
    y = np.asarray(y, int)
    pred = np.asarray(pred, int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    rec = tp / (tp + fn) if tp + fn else np.nan
    spe = tn / (tn + fp) if tn + fp else np.nan
    prec = tp / (tp + fp) if tp + fp else 0.0
    return {'n': len(y), 'events': int(y.sum()), 'auc': roc_auc_score(y, score) if len(set(y)) == 2 else np.nan, 'ap': average_precision_score(y, score) if y.sum() else np.nan, 'accuracy': (tn + tp) / len(y), 'balanced_accuracy': (rec + spe) / 2, 'precision': prec, 'recall': rec, 'f1': 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0, 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp), 'brier': brier_score_loss(y, prob) if prob is not None else np.nan}

class Mapping:

    def __init__(self, a):
        self.models = {}
        for st in [0, 1]:
            x = a
            self.models[st] = []
            for balanced in [False, True]:
                if x.y.nunique() < 2:
                    self.models[st].append(float((x.y.sum() + 1) / (len(x) + 2)))
                    continue
                m = make_pipeline(StandardScaler(), LogisticRegression(C=1.0, solver='lbfgs', max_iter=5000, class_weight='balanced' if balanced else None, random_state=0))
                m.fit(x[['raw']].to_numpy(), x.y)
                self.models[st].append(m)

    def predict(self, d, raw):
        pro = np.zeros(len(d))
        dec = pro.copy()
        for st in [0, 1]:
            mask = d.current_severe.to_numpy() == st
            if not mask.any():
                continue
            for out, m in zip([pro, dec], self.models[st]):
                out[mask] = m if isinstance(m, float) else m.predict_proba(np.asarray(raw)[mask, None])[:, 1]
        return (pro, dec)

def fit_component(dtr, dva, kind, seed, features, loss='mixed', weighted=True, remember=False):
    out = np.zeros(len(dva))
    groups = [0, 1] if kind == 'residual' else [None]
    models = []
    for st in groups:
        a = dtr if st is None else dtr[dtr.current_severe == st]
        mask = np.ones(len(dva), bool) if st is None else dva.current_severe.to_numpy() == st
        if not mask.any():
            continue
        y = a.y if kind == 'trees' else a.next_dest_ton - a.expected_mass if kind in ['residual', 'pooled'] else a.next_dest_ton
        if kind == 'trees':
            m = ExtraTreesClassifier(n_estimators=500, max_depth=8, min_samples_leaf=3, n_jobs=4, random_state=seed)
        else:
            m = CatBoostRegressor(iterations=260, depth=4, learning_rate=0.035, l2_leaf_reg=7, loss_function='Quantile:alpha=0.20' if loss == 'mixed' and st == 1 else 'RMSE', random_seed=seed, thread_count=4, verbose=False, allow_writing_files=False)
        m.fit(a[features], y, sample_weight=base.recencyWeights(a.time) if weighted else np.ones(len(a)))
        if kind == 'trees':
            out[mask] = -m.predict_proba(dva.loc[mask, features])[:, 1] * dva.loc[mask, 'next_baseline']
        else:
            q = m.predict(dva.loc[mask, features])
            out[mask] = q + dva.loc[mask, 'expected_mass'].to_numpy() if kind in ['residual', 'pooled'] else q
        models.append((st, m))
    return (out, models)

def cache_fingerprint(training, validation, features, kind, loss, weighted):
    cols = list(dict.fromkeys(['time', 'y', 'current_severe', 'next_dest_ton', 'next_baseline', 'expected_mass'] + list(features)))
    digest = hashlib.sha256()
    for frame in [training, validation]:
        digest.update(pd.util.hash_pandas_object(frame[cols], index=False).to_numpy().tobytes())
    digest.update(json.dumps([kind, loss, weighted, SEEDS, list(features)], sort_keys=True).encode())
    digest.update(Path(__file__).read_bytes())
    return digest.hexdigest()

def run_model(name, d, kind='ensemble', features=None, loss='mixed', weighted=True, dataset='primary'):
    features = FEATURES if features is None else features
    parts = ['residual', 'direct'] if kind == 'ensemble' else ['pooled', 'direct'] if kind == 'pooledblend' else [kind]
    chunks = []
    foldrows = []
    tonrows = []
    final_components = []
    fingerprints = {}
    manifest_path = OUT / (dataset + ' ' + name + ' Cache.json')
    old_fingerprints = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    for fold in range(4):
        if fold < 3:
            f = FOLDS[fold]
            a = d[d.time < f['train_end']]
            b = d[(d.time >= f['valid_start']) & (d.time < f['valid_end'])]
        else:
            a = d[d.time < '2025-07-01']
            b = d[d.time >= '2025-07-01']
        cachedev = OUT / (dataset + ' ' + name + ' Development.csv')
        cachelat = OUT / (dataset + ' ' + name + ' Predictions.csv')
        fingerprints[str(fold)] = cache_fingerprint(a, b, features, kind, loss, weighted)
        if old_fingerprints.get(str(fold)) == fingerprints[str(fold)] and cachedev.exists() and cachelat.exists() and (not (dataset == 'primary' and name == 'SCPRDFE' and (fold == 3))):
            saved = pd.read_csv(cachedev if fold < 3 else cachelat, parse_dates=['time'])
            if fold < 3:
                saved = saved[saved.fold == fold]
            assert np.array_equal(saved.time.to_numpy(), b.time.to_numpy())
            assert np.array_equal(saved.y.to_numpy(), b.y.to_numpy())
            assert np.allclose(saved.next_baseline.to_numpy(), b.next_baseline.to_numpy())
            q = saved.forecast.to_numpy()
            raw = saved.raw.to_numpy()
            o = b[['time', 'y', 'current_severe', 'next_dest_ton', 'next_baseline']].copy()
            o['raw'] = raw
            o['forecast'] = q
            o['fold'] = fold
            if fold < 3:
                chunks.append(o)
                foldrows.append({'model': name, 'fold': fold + 1, 'training': len(a), 'validation': len(b), 'events': int(b.y.sum()), 'onset_training': int((a.current_severe == 0).sum()), 'persistent_training': int((a.current_severe == 1).sum()), 'raw_auc': roc_auc_score(b.y, raw) if b.y.nunique() == 2 else np.nan, 'raw_ap': average_precision_score(b.y, raw)})
            else:
                later = o
            continue
        qs = []
        models = []
        for part in parts:
            for seed in SEEDS:
                key = (dataset, fold, part, seed, tuple(features), loss if part == 'residual' else 'mean', weighted)
                if key not in CACHE:
                    CACHE[key] = fit_component(a, b, part, seed, features, loss, weighted)
                q, mm = CACHE[key]
                qs.append(q)
                models.append((part, seed, mm))
        q = np.mean(qs, axis=0)
        raw = -q / b.next_baseline.to_numpy()
        o = b[['time', 'y', 'current_severe', 'next_dest_ton', 'next_baseline']].copy()
        o['raw'] = raw
        o['forecast'] = q
        o['fold'] = fold
        if fold < 3:
            chunks.append(o)
            foldrows.append({'model': name, 'fold': fold + 1, 'training': len(a), 'validation': len(b), 'events': int(b.y.sum()), 'onset_training': int((a.current_severe == 0).sum()), 'persistent_training': int((a.current_severe == 1).sum()), 'raw_auc': roc_auc_score(b.y, raw) if b.y.nunique() == 2 else np.nan, 'raw_ap': average_precision_score(b.y, raw)})
        else:
            later = o
            final_components = models
    dev = pd.concat(chunks).sort_values('time')
    cal = dev[dev.time < '2025-05-01']
    thr = dev[dev.time >= '2025-05-01']
    mapping = Mapping(cal)
    pro, dec = mapping.predict(thr, thr.raw)
    thresholds = {st: base.chooseThreshold(thr.loc[thr.current_severe == st, 'y'].to_numpy(), dec[thr.current_severe.to_numpy() == st]) for st in [0, 1]}
    later['probability'], later['decision_score'] = mapping.predict(later, later.raw)
    later['prediction'] = [int(s >= thresholds[int(st)]) for s, st in zip(later.decision_score, later.current_severe)]
    later['model'] = name
    later['dataset'] = dataset
    rows = []
    for st, label in [(None, 'Overall'), (0, 'Onset'), (1, 'Persistence')]:
        z = later if st is None else later[later.current_severe == st]
        rows.append({'model': name, 'group': label, 'dataset': dataset, 'onset_threshold': thresholds[0], 'persistence_threshold': thresholds[1], **metric(z.y, z.prediction, z.probability, z.probability), 'raw_auc': roc_auc_score(z.y, z.raw) if z.y.nunique() == 2 else np.nan, 'mae': mean_absolute_error(z.next_dest_ton, z.forecast), 'rmse': mean_squared_error(z.next_dest_ton, z.forecast) ** 0.5, 'bias': float((z.forecast - z.next_dest_ton).mean())})
    valrows = []
    for st, label in [(None, 'Overall'), (0, 'Onset'), (1, 'Persistence')]:
        mask = np.ones(len(thr), bool) if st is None else thr.current_severe.to_numpy() == st
        y = thr.loc[mask, 'y']
        v = pro[mask]
        valrows.append({'model': name, 'group': label, 'dataset': dataset, 'n': len(y), 'events': int(y.sum()), 'brier': brier_score_loss(y, v), 'auc': roc_auc_score(y, v) if y.nunique() == 2 else np.nan, 'mean_probability': float(v.mean()), 'prevalence': float(y.mean())})
    dev.to_csv(OUT / (dataset + ' ' + name + ' Development.csv'), index=False)
    later.to_csv(OUT / (dataset + ' ' + name + ' Predictions.csv'), index=False)
    manifest_path.write_text(json.dumps(fingerprints, indent=2))
    if dataset == 'primary' and name == 'SCPRDFE':
        FINAL.update(components=final_components, mapping=mapping, thresholds=thresholds, features=features)
    print(name, dataset, rows[0], flush=True)
    return (rows, foldrows, valrows, later)
if __name__ == '__main__':
    print('Building hourly observations', flush=True)
    _, corridor = base.loadTrips()
    h = base.buildHourlyTable(corridor)
    h = h[h.index.normalize() <= corridor.Start.max().normalize()]
    times = h.index[h.hod.isin(base.eligibleHours) & h.baseline.notna() & h.baseline.shift(-1).notna()]
    pi = pipeline(corridor, times, h)
    dall = make_samples(h, pi)
    d = dall[dall.eligible_cutoff].copy()
    h.to_csv(OUT / 'Hourly.csv')
    dall.to_csv(OUT / 'All Clock Samples.csv', index=False)
    d.to_csv(OUT / 'Cutoff Samples.csv', index=False)
    pi.to_csv(OUT / 'Arrival Estimates.csv')
    print('Cutoff samples', len(d), 'development', sum(d.time < '2025-07-01'), 'later', sum(d.time >= '2025-07-01'), 'all clock', len(dall), flush=True)
    audits = {'records': len(corridor), 'duplicate_start_vehicle_permit': int(corridor.duplicated(['Vehicle', 'Permit', 'Start']).sum()), 'duplicate_start_vehicle': int(corridor.duplicated(['Vehicle', 'Start']).sum()), 'over24h': int((corridor.Duration > 1440).sum()), 'boundary_start_hours': int(((corridor.Start.dt.minute == 0) & (corridor.Start.dt.second == 0)).sum()), 'boundary_close_hours': int(((corridor.Close.dt.minute == 0) & (corridor.Close.dt.second == 0)).sum())}
    (OUT / 'Audit.json').write_text(json.dumps(audits, indent=2))
    allrows = []
    foldrows = []
    valrows = []
    preds = []
    for name, kind, cols, loss, w in [('SCPRDFE', 'ensemble', FEATURES, 'mixed', True), ('Residual only', 'residual', FEATURES, 'mixed', True), ('Direct only', 'direct', FEATURES, 'mean', True), ('Mean forecast blend', 'ensemble', FEATURES, 'mean', True), ('Pooled residual blend', 'pooledblend', FEATURES, 'mean', True), ('Without recency', 'ensemble', FEATURES, 'mixed', False), ('Without month', 'ensemble', [x for x in FEATURES if x not in ['month', 'month_sin', 'month_cos']], 'mixed', True), ('Extra Trees', 'trees', FEATURES, 'mean', True)]:
        print('Running', name, flush=True)
        r, f, v, p = run_model(name, d, kind, cols, loss, w)
        allrows += r
        foldrows += f
        valrows += v
        preds.append(p)
        pd.DataFrame(allrows).to_csv(OUT / 'Model Metrics.csv', index=False)
    no = d.copy()
    no.expected_mass = 0
    no.residual_target = no.next_dest_ton
    cols = [x for x in FEATURES if x not in base.featureFamilies['in_transit_pipeline']]
    r, f, v, p = run_model('Without pipeline', no, kind='ensemble', features=cols, dataset='no pipeline')
    allrows += r
    preds.append(p)
    actual = d.copy()
    actual.expected_mass = actual.expected_actual_age
    actual.pipeline_to_baseline = actual.expected_mass / actual.next_baseline
    actual.residual_target = actual.next_dest_ton - actual.expected_mass
    r, f, v, p = run_model('Actual age arrivals', actual, dataset='actual age')
    allrows += r
    preds.append(p)
    capped = d.copy()
    capped.expected_mass = capped.expected_duration_24h
    capped.pipeline_to_baseline = capped.expected_mass / capped.next_baseline
    capped.residual_target = capped.next_dest_ton - capped.expected_mass
    r, f, v, p = run_model('Duration history within 24 hours', capped, dataset='duration')
    allrows += r
    preds.append(p)
    r, f, v, p = run_model('All clock monitoring', dall, dataset='all clock')
    allrows += r
    preds.append(p)
    for boundary in [0.4, 0.6]:
        ds = make_samples(h, pi, boundary)
        ds = ds[ds.eligible_cutoff]
        r, f, v, p = run_model('Boundary ' + str(boundary), ds, dataset='boundary ' + str(boundary))
        allrows += r
        preds.append(p)
    hr = h.copy()
    hr['baseline'] = np.nan
    for hod in range(24):
        hs = h[h.hod == hod]
        for t in hs.index:
            vv = hs.loc[(hs.index < t) & (hs.index >= t - pd.Timedelta(days=90)), 'dest_ton']
            vv = vv[vv > 0]
            if len(vv) >= 10:
                hr.loc[t, 'baseline'] = float(vv.median())
    hr = refresh(hr)
    pir = pi.copy()
    pir.pipeline_to_baseline = pir.expected_mass / hr.baseline.reindex(pir.index + pd.Timedelta(hours=1)).to_numpy()
    dr = make_samples(hr, pir)
    dr = dr[dr.eligible_cutoff]
    r, f, v, p = run_model('90 day reference', dr, dataset='reference')
    allrows += r
    preds.append(p)
    te = d[d.time >= '2025-07-01'].copy()
    delayrows = []
    for delay in [15, 30, 60]:
        print('Simulated delay', delay, flush=True)
        c = corridor.copy()
        c.Start += pd.Timedelta(minutes=delay)
        c.Close += pd.Timedelta(minutes=delay)
        hd = base.buildHourlyTable(c).reindex(h.index)
        hd.baseline = h.baseline
        hd = refresh(hd)
        pdly = pipeline(c, te.time, hd)
        dd = make_samples(hd, pdly)
        dd = dd.set_index('time').reindex(te.time).reset_index()
        dd.next_baseline = te.next_baseline.to_numpy()
        dd.y = te.y.to_numpy()
        dd.next_dest_ton = te.next_dest_ton.to_numpy()
        dd.pipeline_to_baseline = dd.expected_mass / dd.next_baseline
        dd[FEATURES] = dd[FEATURES].replace([np.inf, -np.inf], np.nan).fillna(0)
        qs = []
        for part, seed, mods in FINAL['components']:
            q = np.zeros(len(dd))
            for st, m in mods:
                mask = np.ones(len(dd), bool) if st is None else dd.current_severe.to_numpy() == st
                pp = m.predict(dd.loc[mask, FEATURES])
                q[mask] = pp + dd.loc[mask, 'expected_mass'].to_numpy() if part == 'residual' else pp
            qs.append(q)
        raw = -np.mean(qs, axis=0) / dd.next_baseline.to_numpy()
        pro, dec = FINAL['mapping'].predict(dd, raw)
        pr = np.array([int(s >= FINAL['thresholds'][int(st)]) for s, st in zip(dec, dd.current_severe)])
        row = {'delay_minutes': delay, **metric(dd.y, pr, pro, pro)}
        delayrows.append(row)
        out = te[['time', 'y', 'current_severe']].copy()
        out['probability'] = pro
        out['prediction'] = pr
        out.to_csv(OUT / ('Delay ' + str(delay) + ' Predictions.csv'), index=False)
        print(row, flush=True)
    pd.DataFrame(delayrows).to_csv(OUT / 'Delay Metrics.csv', index=False)
    rules = []
    for name, score, pr in [('Current state', te.current_severe.to_numpy(), te.current_severe.to_numpy()), ('Current tonnage', -te.dest_ton.to_numpy() / te.next_baseline.to_numpy(), (te.dest_ton / te.next_baseline < 0.5).astype(int)), ('Recent three hours', -(te.dest_ton + te.dest_ton_lag1 + te.dest_ton_lag2).to_numpy() / (3 * te.next_baseline.to_numpy()), ((te.dest_ton + te.dest_ton_lag1 + te.dest_ton_lag2) / (3 * te.next_baseline) < 0.5).astype(int)), ('Expected arrivals', -te.expected_mass.to_numpy() / te.next_baseline.to_numpy(), (te.expected_mass / te.next_baseline < 0.5).astype(int))]:
        o = te[['time', 'y', 'current_severe']].copy()
        o['prediction'] = np.asarray(pr)
        o['probability'] = score
        o['model'] = name
        o['dataset'] = 'rule'
        preds.append(o)
        for st, label in [(None, 'Overall'), (0, 'Onset'), (1, 'Persistence')]:
            mask = np.ones(len(te), bool) if st is None else te.current_severe.to_numpy() == st
            rules.append({'model': name, 'group': label, **metric(te.y.to_numpy()[mask], np.asarray(pr)[mask], np.asarray(score)[mask])})
    pd.DataFrame(rules).to_csv(OUT / 'Rule Metrics.csv', index=False)
    pd.DataFrame(allrows).to_csv(OUT / 'Model Metrics.csv', index=False)
    pd.DataFrame(foldrows).to_csv(OUT / 'Development Folds.csv', index=False)
    pd.DataFrame(valrows).to_csv(OUT / 'Calibration Validation.csv', index=False)
    pd.concat(preds).to_csv(OUT / 'All Predictions.csv', index=False)
    arrivalrows = []
    for name, col in [('Age bands', 'expected_mass'), ('Actual ages', 'expected_actual_age'), ('Duration history 24 hours', 'expected_duration_24h')]:
        for target in ['open_target_ton', 'next_dest_ton']:
            arrivalrows.append({'estimator': name, 'target': target, 'n': len(te), 'mae': mean_absolute_error(te[target], te[col]), 'rmse': mean_squared_error(te[target], te[col]) ** 0.5, 'bias': float((te[col] - te[target]).mean())})
    pd.DataFrame(arrivalrows).to_csv(OUT / 'Arrival Error.csv', index=False)
    print('COMPLETE MAIN ANALYSIS', flush=True)
