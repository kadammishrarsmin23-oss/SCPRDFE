from pathlib import Path
import importlib.util
import numpy as np, pandas as pd
s = importlib.util.spec_from_file_location('a', 'Analysis/analyse.py')
a = importlib.util.module_from_spec(s)
s.loader.exec_module(a)
O = Path('Analysis')
d = pd.read_csv(O / 'Cutoff Samples.csv', parse_dates=['time', 'next_time'])
h = pd.read_csv(O / 'Hourly.csv', index_col=0, parse_dates=[0])
hr = h.copy()
hr['neg_cusum_pos'] = 0.0
hr['ratio_pos_ewm3'] = 0.0
hr['ratio_pos_ewm6'] = 0.0
for day, z in h.groupby(h.index.normalize()):
    z = z[(z.hod >= 8) & (z.hod <= 16)]
    for span in [3, 6]:
        hr.loc[z.index, 'ratio_pos_ewm' + str(span)] = z.ratio_pos.ewm(span=span, adjust=False, ignore_na=True).mean()
    run = 0
    for t, rr in z.ratio_pos.items():
        if np.isfinite(rr):
            run = max(0, run + 1 - rr)
        hr.loc[t, 'neg_cusum_pos'] = run
    dd = d.copy()
for col in ['neg_cusum_pos', 'ratio_pos_ewm3', 'ratio_pos_ewm6']:
    dd[col] = hr[col].reindex(dd.time).to_numpy()
r, f, v, p = a.run_model('Daytime history', dd, dataset='daytime')
_, c = a.base.loadTrips()
st = c.Start.astype('int64').to_numpy()
cl = c.Close.astype('int64').to_numpy()
mass = c.SourceQty.to_numpy(float)
rows = []
for t in d.time:
    cutoff = t + pd.Timedelta(hours=1)
    cn = cutoff.value
    known = st < cn
    elapsed = (np.minimum(cl[known], cn) - st[known]) / 60000000000.0
    event = cl[known] < cn
    values, ix, counts = np.unique(elapsed, return_inverse=True, return_counts=True)
    fail = np.bincount(ix, weights=event, minlength=len(values))
    risk = len(elapsed) - np.r_[0, np.cumsum(counts)[:-1]]
    surv = np.cumprod(1 - fail / risk)
    op = known & (cl >= cn)
    ages = (cn - st[op]) / 60000000000.0

    def survival(x):
        ids = np.searchsorted(values, x, side='right') - 1
        return np.where(ids >= 0, surv[np.maximum(ids, 0)], 1.0)
    sa = survival(ages)
    sb = survival(ages + 60)
    prob = np.divide(sa - sb, sa, out=np.zeros(len(sa)), where=sa > 0)
    rows.append({'time': t, 'expected_km': float((mass[op] * prob).sum())})
k = pd.DataFrame(rows)
k.to_csv(O / 'Censor Aware Arrivals.csv', index=False)
dk = d.merge(k, on='time', validate='one_to_one')
dk.expected_mass = dk.expected_km
dk.pipeline_to_baseline = dk.expected_mass / dk.next_baseline
dk.residual_target = dk.next_dest_ton - dk.expected_mass
r2, f, v, p2 = a.run_model('Censor aware actual ages', dk, dataset='survival')
met = pd.read_csv(O / 'Model Metrics.csv')
met = pd.concat([met, pd.DataFrame(r + r2)])
met.to_csv(O / 'Model Metrics.csv', index=False)
pp = pd.read_csv(O / 'All Predictions.csv')
pp = pd.concat([pp, p, p2])
pp.to_csv(O / 'All Predictions.csv', index=False)
from sklearn.metrics import mean_absolute_error, mean_squared_error
te = dk[dk.time >= '2025-07-01']
ar = pd.read_csv(O / 'Arrival Error.csv')
more = []
for target in ['open_target_ton', 'next_dest_ton']:
    more.append({'estimator': 'Censor aware actual ages', 'target': target, 'n': len(te), 'mae': mean_absolute_error(te[target], te.expected_mass), 'rmse': mean_squared_error(te[target], te.expected_mass) ** 0.5, 'bias': float((te.expected_mass - te[target]).mean())})
pd.concat([ar, pd.DataFrame(more)]).to_csv(O / 'Arrival Error.csv', index=False)
print('COMPLETE EXTRA CHECKS', flush=True)
