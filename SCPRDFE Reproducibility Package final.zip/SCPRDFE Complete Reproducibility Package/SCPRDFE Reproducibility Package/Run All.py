from pathlib import Path
import os
import sys
import subprocess
import hashlib
import json
import platform
import importlib.metadata
import time

root = Path(__file__).resolve().parent
os.chdir(root)
mode = sys.argv[1] if len(sys.argv) > 1 else 'all'
if mode not in ['all', 'verify']:
    raise ValueError('Use all or verify as the optional run mode')
results = root / 'Results'
results.mkdir(exist_ok=True)
if mode == 'all':
    candidates = [p for p in root.glob('*.xlsx') if 'annexureii' in ''.join(p.stem.lower().split()) and 'annexureiii' not in ''.join(p.stem.lower().split())]
    if len(candidates) != 1:
        raise FileNotFoundError('Place exactly one Annexure II Excel workbook beside Run All.py')
    workbook = candidates[0].resolve()
    os.environ['SCPRDFE DATA'] = str(workbook)
    os.environ['OMP_NUM_THREADS'] = '4'
    os.environ['OPENBLAS_NUM_THREADS'] = '4'
    os.environ['MKL_NUM_THREADS'] = '4'
    provenance = {'Workbook': workbook.name, 'Workbook SHA256': hashlib.sha256(workbook.read_bytes()).hexdigest(), 'Python': platform.python_version(), 'Platform': platform.platform(), 'Packages': {name: importlib.metadata.version(name) for name in ['numpy', 'pandas', 'scikit-learn', 'catboost', 'openpyxl', 'joblib', 'tqdm']}}
    (results / 'Run Environment.json').write_text(json.dumps(provenance, indent=2))
    steps = ['Analysis/analyse.py', 'Analysis/extra.py', 'Representation Selection/run.py', 'Probability Calibration/refit.py', 'Learner Comparison/train.py', 'Learner Comparison/select.py', 'Final Audit.py', 'Paper Figures.py']
else:
    steps = ['Final Audit.py']
for number, relative in enumerate(steps, 1):
    print(f'Stage {number} of {len(steps)}: {relative}', flush=True)
    started = time.time()
    log = results / ('Stage ' + str(number) + ' Log.txt')
    with log.open('w') as stream:
        process = subprocess.Popen([sys.executable, str(root / relative)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in process.stdout:
            print(line, end='', flush=True)
            stream.write(line)
            stream.flush()
        status = process.wait()
    if status:
        raise RuntimeError('Stage failed. See ' + log.name)
    print('Stage completed in ' + str(round(time.time() - started, 1)) + ' seconds', flush=True)
print('Reproduction completed. See the Results folder and Verification Report.json.', flush=True)
